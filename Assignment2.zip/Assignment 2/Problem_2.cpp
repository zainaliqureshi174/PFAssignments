//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 2

#include <iostream>
using namespace std;

int main ()
{
int a,b ;
a= rand()%100;
	cout<<"Welcome to HI-LO game.\n";
	cout<<"1: Guess a number between 1 and 100 : ";
	cin >>b;
	if(b > 0 && b < 101)
	{
		if (b<a) 
		{
			cout<<"Sorry! Your guess is too low.\n";
			cout<<"2: Guess a number between 1 and 100 again : ";
			cin>>b;
				if (b<a)
				{
					cout<<"Sorry! Your guess is too low.\n";
					cout<<"3: Guess a number between 1 and 100 again : ";
					cin>>b;
						if (b<a)
						{
							cout<<"Sorry! Your guess is too low.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
								if (b<a)
								{
									cout<<"Sorry! Your guess is too low.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
								else if (b>a)
								{
									cout<<"Sorry! Your guess is too High.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
						}
						else if (b>a)
						{
							cout<<"Sorry! Your guess is too High.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
								if (b<a)
								{
									cout<<"Sorry! Your guess is too low.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
								else if (b>a)
								{
									cout<<"Sorry! Your guess is too High.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
						}
				}
				else if (b>a)
				{
					cout<<"Sorry! Your guess is too High.\n";
					cout<<"3: Guess a number between 1 and 100 again : ";
					cin>>b;
						if (b<a)
						{
							cout<<"Sorry! Your guess is too low.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
								if (b<a)
								{
									cout<<"Sorry! Your guess is too low.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
								else if (b>a)
								{
									cout<<"Sorry! Your guess is too High.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
						}
						else if (b>a)
						{
							cout<<"Sorry! Your guess is too High.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
								if (b<a)
								{
									cout<<"Sorry! Your guess is too low.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
								else if (b>a)
								{
									cout<<"Sorry! Your guess is too High.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
						}
				}
		}
		else if (b>a)
		{
			cout<<"Sorry! Your guess is too high.\n";
			cout<<"2: Guess a number between 1 and 100 again : ";
			cin>>b;
				if (b<a)
				{
					cout<<"Sorry! Your guess is too low.\n";
					cout<<"3: Guess a number between 1 and 100 again : ";
					cin>>b;
						if (b<a)
						{
							cout<<"Sorry! Your guess is too low.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
								if (b<a)
								{
									cout<<"Sorry! Your guess is too low.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
								else if (b>a)
								{
									cout<<"Sorry! Your guess is too High.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
						}
						else if (b>a)
						{
							cout<<"Sorry! Your guess is too High.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
								
								if (b<a)
								{
									cout<<"Sorry! Your guess is too low.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
								else if (b>a)
								{
									cout<<"Sorry! Your guess is too High.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
						}
				}
				else if (b>a)
				{
					cout<<"Sorry! Your guess is too High.\n";
					cout<<"3: Guess a number between 1 and 100 again : ";
					cin>>b;
						if (b<a)
							{
							cout<<"Sorry! Your guess is too low.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
								if (b<a)
								{
									cout<<"Sorry! Your guess is too low.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
								else if (b>a)
								{
									cout<<"Sorry! Your guess is too High.\n";
									cout<<"5: Guess a number between 1 and 100 again : ";
									cin>>b;
										if (b!=a)
										{
											cout<<"Sorry You lost! Your guess is too low.\n";
										}
								}
						}
						else if (b>a)
						{
							cout<<"Sorry! Your guess is too High.\n";
							cout<<"4: Guess a number between 1 and 100 again : ";
							cin>>b;
						}
				}
		}
		else if (b==a)
		{
			cout<<"Congratulations !! Your guess is true. You won!\n";
		}
	}
	else
	{
		cout<<"\nOut of range!\n";
	}
		

return 0;
}
