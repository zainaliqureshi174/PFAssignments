//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 1

#include<iostream>
using namespace std;
int main (){
string a;  						//string is used for the user name.
long int c,b,d,e, z, y, x, w, v, u, t, s, r;  		//long int is used because CNIC has 13 intigers.
	cout << "Enter your name : ";
	cin >> a;
	
	cout << "Enter your 13 digit CNIC Number : ";
	cin >> b;
	
	cout << "Details are as under: \n";
	
	z=b/1000000000000;			//1st number of CNIC
	y=b%1000000000000;
	x=y/100000000000;			//2nd number of CNIC
	w=y%100000000000;
	v=w/10000000000;			//3rd number of CNIC
	u=w%10000000000;
	t=u/1000000000;				//4th number of CNIC
	s=u%1000000000;
	r=s/100000000;				//5th number of CNIC
	e=b%10;
	c=b/10;
	d=c%10000000;
	//cout << b << z << x << v << t << r << endl; 
		if(e%2==0)
		{
			cout<<a<<" is Female.\n";
		}
		else
		{
			cout<<a<<" is Male.\n";
		}
		if (z==1)
		{
			cout<<a<<" belongs to Khyber Pakhtun Kha Province.\n";
				if (x==1)
				{
					cout<<a<<" belongs to Bannu Division.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Bannu district.\n";
								if (t==0)
								{
									cout<<a<<" belongs to Bannu tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Domel tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Miryan tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Bakakhel tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Kakki tehsil.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Lakki Marwat district.\n";
								if (t==0)
								{
									cout<<a<<" belongs to Lakki Marwat tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to North Waziristan District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to North Waziristan tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else
						{
							cout << "Invalide CNIC number.\n";
						}
				}
				else if (x==2)
				{
					cout<<a<<" belongs to Dera Ismail Khan Division.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Dera Ismail Khan district.\n";
								if (t==0)
								{
									cout<<a<<" belongs to Dera Ismail Khan tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Tank district.\n";
								if (t==0)
								{
									cout<<a<<" belongs to Tank tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to Lower South Waziristan District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to Lower South Waziristan tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==4)
						{
							cout<<a<<" belongs to Upper South Waziristan District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to Upper South Waziristan tehsil.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else
						{
							cout << "Invalide CNIC number.\n";
						}
				}
				else if (x==3)
				{
					cout<<a<<" belongs to Hazara Division.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Abbottabad District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Battagram District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to Haripur District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==4)
						{
							cout<<a<<" belongs to Kolai-Palas District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==5)
						{
							cout<<a<<" belongs to Upper Kohistan District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
				}
				else if (x==4)
				{
					cout<<a<<" belongs to Kohat Division.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Hangu District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Karak District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to Kohat District.\n";if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==4)
						{
							cout<<a<<" belongs to Kurram District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==5)
						{
							cout<<a<<" belongs to Orakzai District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
				}
				else if (x==5)
				{
					cout<<a<<" belongs to Malakand Division.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Buner District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Lower Chitral District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to Lower Dir District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==4)
						{
							cout<<a<<" belongs to Malakand District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==5)
						{
							cout<<a<<" belongs to Shangla District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
				}
				else if (x==6)
				{
					cout<<a<<" belongs to Mardan Division.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Mardan District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Swabi District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
				}
				else if (x==7)
				{
					cout<<a<<" belongs to Pishawar Division.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Pishawar District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Charsadda District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to Nowshera District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==4)
						{
							cout<<a<<" belongs to Khyber District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==5)
						{
							cout<<a<<" belongs to Mohmand District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
				}
				else 
				{		
			        	cout << "Invalid CNIC Number.\n";
				}
			}
		else if (z==2)
			{
				cout<<a<<" belongs to Federally Administered Tribal Areas (Fata).\n";
					if (x==1)
				{
					cout<<a<<" belongs to Bajaur Agency.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Khaar District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Nawagai District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
						
				}
				else if (x==2)
				{
					cout<<a<<" belongs to Mohmand Agency.\n";
						if (v==1)
						{
							cout<<a<<" belongs to District-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to District-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
						
				}
				else if (x==3)
				{
					cout<<a<<" belongs to Khyber Agency.\n";
						if (v==1)
						{
							cout<<a<<" belongs to District-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to District-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
						
				}
				else if (x==4)
				{
					cout<<a<<" belongs to Orakzai Agency.\n";
						if (v==1)
						{
							cout<<a<<" belongs to District-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to District-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
						
				}
				else if (x==5)
				{
					cout<<a<<" belongs to Kurram Agency.\n";
						if (v==1)
						{
							cout<<a<<" belongs to District-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to District-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
						
				}
				else if (x==6)
				{
					cout<<a<<" belongs to North Waziristan Agency.\n";
						if (v==1)
						{
							cout<<a<<" belongs to District-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to District-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else 
						{
							cout << "Invalide CNIC number.\n";
						}
						
				}
				else if (x==7)
				{
					cout<<a<<" belongs to South Waziristan Agency.\n";
						if (v==1)
						{
							cout<<a<<" belongs to Ladha District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to Charsadda District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to Nowshera District.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
				}
				else 
				{		
			        	cout << "Invalid CNIC Number.\n";
				}
			}
		else if (z==3)
			{
				cout<<a<<" belongs to Punjab.\n";
					if (x==1)
					{
						cout<<a<<" belongs to Bahawalpur Division.\n";
							if (v==1)
						{
							cout<<a<<" belongs to district-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to district-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to District-3.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else
						{
							cout << "Invalide CNIC number.\n";
						}
					}
					else if (x==2)
					{
						cout<<a<<" belongs to Dera Ghazi Khan Division.\n";
							if (v==1)
							{
							cout<<a<<" belongs to district-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to district-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to District-3.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else
						{
							cout << "Invalide CNIC number.\n";
						}
					}
					else if (x==3)
					{
						cout<<a<<" belongs to Faisalabad Division.\n";
							if (v==1)
							{
							cout<<a<<" belongs to district-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to district-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to District-3.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else
						{
							cout << "Invalide CNIC number.\n";
						}
					}

					else if (x==4)
					{
						cout<<a<<" belongs to Gujranwala Division.\n";
							if (v==1)
							{
							cout<<a<<" belongs to district-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==2)
						{
							cout<<a<<" belongs to district-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
						}
						else if (v==3)
						{
							cout<<a<<" belongs to District-3.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
							}
							if (v==4)
							{
							cout<<a<<" belongs to district-4.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
						}
						if (v==5)
							{
							cout<<a<<" belongs to district-5.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								
						}
						
					}
					else if (x==5)
					{
						cout<<a<<" belongs to Gujrat Division.\n";
							if (v==1)
							{
							cout<<a<<" belongs to district-1.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										else
										{
											cout << "Invalide CNIC number.\n";
										}
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								
						}
						else if (v==2)
						{
							cout<<a<<" belongs to district-2.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								
						}
						else if (v==3)
						{
							cout<<a<<" belongs to District-3.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==1)
								{
									cout<<a<<" belongs to Tehsil-1 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==2)
								{
									cout<<a<<" belongs to Tehsil-2 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==3)
								{
									cout<<a<<" belongs to Tehsil-3 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==4)
								{
									cout<<a<<" belongs to Tehsil-4 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==5)
								{
									cout<<a<<" belongs to Tehsil-5 .\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else
								{
									cout << "Invalide CNIC number.\n";
								}
								}
							if (v==4)
							{
							cout<<a<<" belongs to district-4.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								
						}
						if (v==5)
							{
							cout<<a<<" belongs to district-5.\n";
								if (t==0)
								{
									cout<<a<<" belongs to tehsil-0.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==1)
								{
									cout<<a<<" belongs to tehsil-1.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==2)
								{
									cout<<a<<" belongs to tehsil-2.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==3)
								{
									cout<<a<<" belongs to tehsil-3.\n";
										if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								else if (t==4)
								{
									cout<<a<<" belongs to tehsil-4.\n";
									if (r==1)
										{
											cout<<a<<" belongs to Union council-1 .\n";
										}
										else if (r==2)
										{
											cout<<a<<" belongs to Union council-2 .\n";
										}
										else if (r==3)
										{
											cout<<a<<" belongs to Union council-3 .\n";
										}
										else if (r==4)
										{
											cout<<a<<" belongs to Union council-4 .\n";
										}
										else if (r==5)
										{
											cout<<a<<" belongs to Union council-5 .\n";
										}
										
								}
								
						}
						
					}
					
			}
		else if (z==4)
			{
				cout<<a<<" belongs to Sindh.\n";
					if (x==1)
					{
						cout<<a<<" belongs to Bhanbhor Division.\n";
					}
					else if (x==2)
					{
						cout<<a<<" belongs to Hyderabad Division.\n";
					}
					else if (x==3)
					{
					cout<<a<<" belongs to Karachi Division.\n";
					}
					else if (x==4)
					{
						cout<<a<<" belongs to Sukher Division.\n";
					}
					else if (x==5)
					{
						cout<<a<<" belongs to Larkana Division.\n";
					}
					
			}
		else if (z==5)
			{
				cout<<a<<" belongs to Balochistan.\n";
					if (x==1)
					{
					cout<<a<<" belongs to Division-1.\n";
					}
					else if (x==2)
					{
						cout<<a<<" belongs to Division-2.\n";
					}
					else if (x==3)
					{
						cout<<a<<" belongs to Division-3.\n";
					}
					else if (x==4)
					{
						cout<<a<<" belongs to Division-4.\n";
					}
					else if (x==5)
					{
						cout<<a<<" belongs to Division-5.\n";
					}
					
			}
		else if (z==6)
			{
				cout<<a<<" belongs to Islamabad.\n";
					if (x==1)
					{
						cout<<a<<" belongs to Zone I.\n";
					}
					else if (x==2)
					{
						cout<<a<<" belongs to Zone II.\n";
					}
					else if (x==3)
					{
						cout<<a<<" belongs to Zone III.\n";
					}
					else if (x==4)
					{
						cout<<a<<" belongs to Zone IV.\n";
					}
					else if (x==5)
					{
						cout<<a<<" belongs to Zone V.\n";
					}
		
			}
		else 
		 cout <<"Invalid cnic";
		
		cout<<"Family number of "<<a<<" is "<<d<<endl;
return 0;
}
