//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 9-b

#include <iostream>
using namespace std;
int main()
{
    int w, x, y, z;
    cout<<"Enter Four numbers : ";
    cin >>w>>x>>y>>z;
    (w>x && w>y && w>z)?cout<<w<<" is the greatest number.\n":(x>w && x>y && x>z)?cout<<x<<" is the greatest number.\n":(y>w && y>x && y>z)?cout<<y<<" is the greatest number.\n":cout<<z<<" is the greatest number.\n";
    return 0;
}
