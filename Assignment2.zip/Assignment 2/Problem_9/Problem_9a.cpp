//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 9-a

#include <iostream>
using namespace std;
int main()
{
    int x, y, z;
    cout<<"Enter three numbers : ";
    cin >>x>>y>>z;
    cout<<"\nThe greatest number is : "<<(( x > y ) ? ( x > z ) ? x : z : (( y > z ) ? y : z )) ;
    cout<<endl;
    return 0;
}
