//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 10-c

#include <iostream>

using namespace std;

int main()
{
    int x;
    cout<<"Enter a year : ";
    cin >>x;
        if (x%4==0)
        {
            cout<<"It is a leap year.\n";
        }
        else 
        cout <<"It is not a leap year.\n";
    return 0;
}
