//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 10-a

#include <iostream>

using namespace std;

int main()
{
    char ch;
        cout << "Enter a character : ";
        cin >> ch;
            if ((ch>=97)&&(ch<=122))
            {
                cout << "It is a Lower case Alphabet.\n";
            }
            else 
            {
                cout << "It is not a lower case alphabet.\n";
            }

    return 0;
}
