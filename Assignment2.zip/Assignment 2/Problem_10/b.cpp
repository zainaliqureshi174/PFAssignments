//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 10-b

#include <iostream>

using namespace std;

int main()
{
    char ch;
        cout << "Enter a character : ";
        cin >> ch;
            if ((ch>=65)&&(ch<=90))
            {
                cout << "It is not a special character.\n";
            }
            else if ((ch>=97)&&(ch<=122))
            {
                cout << "It is not a special character.\n";
            }
            else 
            {
                cout << "It is a special character.\n";
            }

    return 0;
}
