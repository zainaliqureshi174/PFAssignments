//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 4

#include <iostream>
using namespace std;
int main()
{
char ch1, ch2; 
	cout <<"Answer these questions and I'll guese a shape:\n3 2 1 ...\n";
	cout <<"Q1. Are all sides equal? (Y or N)\n";
	cin >>ch1;
	cout <<"Q2. Are all angles 90 degrees? (Y or N)";
	cin >>ch2;
	
	if ((ch1 == 'y' || ch1 == 'Y')&&(ch2 == 'y' || ch2 == 'Y'))
	{
		cout <<"I got it! It’s a SQUARE.\n";
	}
	else if ((ch1 == 'n' || ch1 == 'N')&&(ch2 == 'y' || ch2 == 'Y'))
	{
		cout <<"I got it! It’s a RECTANGLE.\n";
	}
	else if ((ch1 == 'y' || ch1 == 'Y')&&(ch2 == 'n' || ch2 == 'N'))
	{
		cout <<"I got it! It’s a ROHMBUS.\n";
	}
	else if ((ch1 == 'n' || ch1 == 'N')&&(ch2 == 'n' || ch2 == 'N'))
	{
		cout <<"I got it! It’s a TRAPEZIUM.\n";
	}
return 0;
}
