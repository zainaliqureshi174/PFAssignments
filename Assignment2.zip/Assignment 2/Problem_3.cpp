//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 3

#include <iostream>
using namespace std;
int main()
{
int x;
int y;
int z;
	cout<<"Enter total wheels ";
	cin>>x;
	cout<<"Enter total bodies ";
	cin>>y;
	cout<<"Enter total people figures ";
	cin>>z;
	x = x/4;
	z = z/2;
		if(x<y && x<z)
		{
			cout<<"There will total "<<x<<" cars build.\n";
		}
		else if(y<x && y<z)
		{
			cout<<"There will total "<<y<<" cars build.\n";
		}	
		else if(z<x && z<y)
		{
			cout<<"There will total "<<z<<" cars build.\n";
		}
return 0;
}
