//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 6

#include <iostream>
using namespace std;
int main()
{int a, b=3;
    cout<<"Enter a number to check Power of 2 : ";
    cin>>a;
        if (a&b)
        {
            cout<< "It is not in power of 2.\n";
        }
        else cout<<"It is in power of 2.\n";
    return 0;
}
