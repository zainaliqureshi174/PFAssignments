//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 7

#include <iostream>
using namespace std;
int main()
{int a;
    cout<<"Enter a number to check Even or Odd : ";
    cin>>a;
        if (a&1==1)
        {
            cout<< "It is odd.\n";
        }
        else cout<<"It is even";
    return 0;
}
