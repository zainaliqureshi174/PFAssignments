//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 5

#include <iostream>
using namespace std;
int main()
{
string password;
int b;
	cout <<"Enter a Password : ";
	cin>>password;
	b= sizeof();
	//cout<<b;
	if (b>=6)
	{
		if(){}
	}
    return 0;
}
