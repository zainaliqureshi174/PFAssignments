//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 2 Programing fundamentals
//Dated: 8th Octuber 2022
//Problem 8

#include <iostream>
using namespace std;

int main()
{
int x = 0, y = 0, avg = 1;
	cout << "Enter two numbers for their average\n";
	cin >> x >> y;
	
	avg = ((x + y) >> 1);
	
	cout << avg << endl;
return 0 ; 
}
