//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 3 Programing fundamentals
//Dated: 23rd Octuber 2022
//Problem 6

#include <iostream>
using namespace std;

int main() {
	int num, largestnum;					//num is the number of diamonds to print in rows. 
	
	cout<<"\nEnter number of Diamonds: \n";
	cin>>num;
	cout << "\nEnter the largest number: \n";
	cin >> largestnum;
	
	
	for (int i = 1; i <= largestnum; i++) {			//loop for rows.
		
			int a = largestnum - i;			
			for (int j = 1; j <= a; j++) { 		//loop for spaces.
				cout << " ";
			}
			for (int f = 1; f <= i; f++) {		//loop for left upper part of diamond.
				cout << i - (f - 1);
			}
			for (int m = 1; m <= i; m++)		//loop for right upper part of diamond.
			{
				cout << m ;
			}
			
		for (int z = 1; z <= num-1; z++) {		//loop for next upper diamond in same lines.
 
			for (int j = 1; j <= 2*a; j++) { 	//loop for spaces and ( 2*a ) spaces are doubled.
				cout << " ";
			} 
			for (int f = 1; f <= i; f++) {		//loop for left upper part of next diamond.
				cout << i - (f - 1);
			}
			for (int m = 1; m <= i; m++)		//loop for right upper part of next diamond.
			{
				cout << m ;
			}
		}
			cout << endl;
		
	}
	for (int i = largestnum - 1; i >= 1; i--) {		//loop fore rows.
	
			int a = largestnum - i;
			for (int j = a; j >= 1; j--) {		//loop for spaces.
				cout << " ";
			}
			for (int f = i; f >= 1; f--) {		//loop for left lower part of diamond.
				cout << f;
			}
			for (int m = i; m >= 1; m--)		//loop for right lower part of diamond.
			{
				cout << i - (m - 1);
			}
			
		for (int z = 1; z <= num-1; z++) {		//loop for next lower diamond in same lines.
		
			for (int j = 2*a; j >= 1; j--) {	//loop for spaces and ( 2*a ) spaces are doubled.
				cout << " ";
			}
			for (int f = i; f >= 1; f--) {		//loop for left lower part of next diamond.
				cout << f;
			}
			for (int m = i; m >= 1; m--)		//loop for right lower part of next diamond.
			{
				cout << i - (m - 1);
			}
		}	
			cout << endl;
		
	}

	return 0;
}
