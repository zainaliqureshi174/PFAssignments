//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 3 Programing fundamentals
//Dated: 23rd Octuber 2022
//Problem 7

#include<iostream>
using namespace std;

int main()
{
	string word;
	short int first = 0, second = 5, third = 6, fourth = 2; 		//My roll number is 0562 
	
	cout << "This program is valid for maximum 6 UPPER CASE alphabets and also for 5 lower case alphabets.\n\n";
	cout << "Enter a word of max. 6 characters : ";
	while (true) {								//loop for input valid characters.

		cin >> word;
		if (word.length() > 0 && word.length() <= 6) {			//Word length is set 6
			break;
		}
		cout << "Error!!! Enter only 6 alphabets.\n";
	}

	string final = "";

	int index = 1;
	long long temp = word[0];
	for (int i = 0; i < word.length() + 3; i++)
	{
		int temp2 = word[index];
		if (i == 0 || i == 2 || i == 4 || i == 6)
		{
			switch (i)
			{
				case 0:
					temp = (temp * 10) + first;		//for 1st digit of roll number insertion
					break;
				case 2:
					temp = (temp * 10) + second;		//for 2nd digit of roll number insertion
					break;
				case 4:
					temp = (temp * 10) + third;		//for 3rd digit of roll number insertion
					break;
				case 6:
					temp = (temp * 10) + fourth;		//for 4th digit of roll number insertion
					break;
			}
		}
		else
		{
			if (index == word.length())
				break;
			if (temp2 >= 100)
			{
				temp = (temp * 1000) + temp2;			//for lower case alphabets
			}
			else
			{
				temp = (temp * 100) + temp2;			//for UPPER CASE alphabets
			}
			index++;
		}
	}

	cout << temp;

	return 0;
}
