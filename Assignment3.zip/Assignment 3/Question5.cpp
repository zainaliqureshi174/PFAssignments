//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 3 Programing fundamentals
//Dated: 23rd Octuber 2022
//Problem 5

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main ()
{

string sen;

	cout << "Eneter a Sentence : ";
	
return 0;}
