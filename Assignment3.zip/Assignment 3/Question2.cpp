//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 3 Programing fundamentals
//Dated: 23rd Octuber 2022
//Problem 2

#include<iostream>
using namespace std;

int main()
{
float size ;							//float for the input

	cout << "Enter the size of the pattern between 1 and 2 : ";
	cin >>size;
	
	if (size >= 1 && size < 1.5) {				//for between 1 and 1.5
	
		for (int i = 1; i <= 35; i++) {			//1st outer loop for row 1 to 35
			for (int j = 1; j <= 17; j++) {		//1st inner loop for columns of row 1 to 35
				if (j <= 3 || j >= 15) {	//for starting and ending spaces
					if (i == 2) {
					cout << "-";
					}
					else if (i >= 32 && i <=35) {
						if (j == 2 || j == 3 || j ==15 || j ==16) {
						cout << "|";
						}
						else {
						cout << " ";
						}
					}
					else {
					cout << " ";
					}
				}
				else {
					if (i <=13) {
					cout << "*";
					}
					else if (i >13 && i <= 35) {
						if (j == 6 || j == 12) {
						cout << "|";
						}
						else {
						cout << "*";
						}
					}
				}
				
			}
			cout <<endl;
		}
		for (int k = 36; k <= 39; k++) {		//2nd outer loop for row 36 to 39
			for (int j = 1; j <= 17; j++) {		//2nd inner loop for columns of row 36 to 39
				if (k >=36 && k <=39) {
						if (k == 36) {
							if (j == 1 || j == 17) {
							cout << " ";
							}
							else 
							cout << "-";
						}
						else {
							if (j <= 3 || j >=15) {
								cout << " ";
							}
							else 
								cout <<"^";
						}
				}
			}
			cout <<endl;
		}
	}
	
	else if (size > 1.4 && size < 2) {
	
		for (int i = 1; i <= 59; i++) {
			for (int j = 1; j <= 25; j++) {
				if (j <= 4 || j >= 22) {
					if (i == 2) {
					cout << "-";
					}
					else if (i >= 53 && i <= 59) {
						if (j == 2 || j == 3 || j == 4 || j == 22 || j == 23 || j == 24) {
						cout << "|";
						}
						else {
						cout << " ";
						}
					}
					else {
					cout << " ";
					}
				}
				else {
					if (i <= 25) {
					cout << "*";
					}
					else if (i > 25 && i <= 59) {
						if (j == 8 || j == 18) {
						cout << "|";
						}
						else {
						cout << "*";
						}
					}
				}	
			}
			cout <<endl;
		}
		for (int k = 54; k <= 59; k++) {
			for (int j = 1; j <= 25; j++) {
				if (k >=54 && k <=59) {
					if (k == 54) {
						if (j == 1 || j == 25) {
						cout << " ";
						}
						else 
						cout << "-";
					}
					else {
						if (j <= 4 || j >= 22) {
							cout << " ";
						}
						else 
							cout <<"^";
					}
				}
			}
			cout <<endl;
		}
	}
	
	else if (size == 2) {
	
		for (int i = 1; i <= 75; i++) {
			for (int j = 1; j <= 34; j++) {
				if (j <= 6 || j >= 29) {
					if (i == 3 || i == 4) {
					cout << "-";
					}
					else if (i >= 68 && i <= 75) {
						if (j == 3 || j == 4 || j == 5 || j == 6 || j == 29 || j == 30 || j ==31 || j == 32) {
						cout << "|";
						}
						else {
						cout << " ";
						}
					}
					else {
					cout << " ";
					}
				}
				else {
					if (i <=32) {
					cout << "*";
					}
					else if (i >32 && i <= 75) {
						if (j == 11 || j == 12 || j == 23 || j == 24) {
						cout << "|";
						}
						else {
						cout << "*";
						}
					}
				}
				
			}
			cout <<endl;
		}
		for (int k = 75; k <= 82; k++) {
			for (int j = 1; j <= 34; j++) {
				if (k >=75 && k <=82) {
						if (k == 75 || k == 76) {
							if (j == 1 || j == 2 || j == 33 || j == 34) {
							cout << " ";
							}
							else 
							cout << "-";
						}
						else {
							if (j <= 6 || j >= 29) {
								cout << " ";
							}
							else 
								cout <<"^";
						}
				}
			}
			cout <<endl;
		}
	}
return 0;
}
