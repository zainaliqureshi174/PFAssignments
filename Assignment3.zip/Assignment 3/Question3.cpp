//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 3 Programing fundamentals
//Dated: 23rd Octuber 2022
//Problem 3

#include <iostream>
using namespace std;

int main()
{
    cout<<"\t\tMENU\n";							//Menue 
    cout<<"Sr\tName\t\t\tPrice\n";
    cout<<"1.\tZinger Shawarma\t\t200\n";
    cout<<"2.\tGrill Shawarma\t\t170\n";
    cout<<"3.\tChicken Shawarma\t130\n";
    cout<<"4.\tZinger Burger\t\t250\n";
    cout<<"5.\tGrill Burger\t\t220\n";
    cout<<"6.\tChicken Burger\t\t180\n";
    cout<<"7.\tZinger Sandwich\t\t270\n";
    cout<<"8.\tGrill Sandwich\t\t240\n";
    cout<<"9.\tChicken Sandwich\t200\n";
    cout<<"10.\tRoll Paratha\t\t200\n";
    cout<<"11.\tSamosa Chat\t\t150\n";
    cout<<"12.\tSmall Fries\t\t80\n";
    cout<<"13.\tLarge Fries\t\t150\n";
    cout<<"14.\tBiryani\t\t\t200\n";
    cout<<"15.\tPulao\t\t\t180\n\n";

    string item1="0", item2="0", item3="0", item4="0", item5="0", item6="0", name="";

    int quantity1=0, quantity2=0, quantity3=0, quantity4=0, quantity5=0, quantity6=0;

    int total1=0, total2=0, total3=0, total4=0, total5=0, total6=0;

    int temp;
    double bill=0, C_num;
    int item;
    char option;
    int tax=0;
    
	cout << "Enter your name: ";					//User name input 
	cin >> name;				
	cout << "Enter your contact number: ";				//User contact number input
	cin >> C_num;

        cout<<"\nEnter the serial number of item:";			//input Seriel number for order 
        cin>>item;
        cout<<"Enter the quantity of item:";				//input the quantity of the item
        cin>>quantity1;
        switch(item)
        {
    case 1:
        {
        temp=200;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Zinger Shawarma";
        break;
        }

    case 2:
        {
        temp=170;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Grill Shawarma";
        break;
        }

    case 3:
        {
        temp=130;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Chicken Shawarma";
        break;
        }

    case 4:
        {
        temp=250;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Zinger Burger";
        break;
        }

    case 5:
        {
        temp=220;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Grill Burger";
        break;
        }

    case 6:
        {
        temp=180;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Chicken Burger";
        break;
        }

    case 7:
        {
        temp=270;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Zinger Sandwich";
        break;
        }

    case 8:
        {
        temp=240;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Grill Sandwich";
        break;
        }

    case 9:
        {
        temp=200;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Chicken Sandwich";
        break;
        }

    case 10:
        {
        temp=200;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Roll Paratha";
        break;
        }

    case 11:
        {
        temp=150;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Samosa Chat";
        break;
        }

    case 12:
        {
        temp=80;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Small Fries";
        break;
        }

    case 13:
        {
        temp=150;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Large Fries";
        break;
        }

    case 14:
        {
        temp=2000;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Biryani";
        break;
        }

    case 15:
        {
        temp=180;
        total1=temp*quantity1;
        bill=bill+total1;
        item1="Pulao";
        break;
        }
        }

        cout<<"Do you want to buy another item(Y or N):";
        cin>>option;
        if(option == 'Y' || option == 'y')
        {
        cout<<"\nEnter the serial number of item:";
        cin>>item;
        cout<<"Enter the quantity of item:";
        cin>>quantity2;
        switch(item)
        {
    case 1:
        {
        temp=200;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Zinger Shawarma";
        break;
        }

    case 2:
        {
        temp=170;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Grill Shawarma";
        break;
        }

    case 3:
        {
        temp=130;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Chicken Shawarma";
        break;
        }

    case 4:
        {
        temp=250;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Zinger Burger";
        break;
        }

    case 5:
        {
        temp=220;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Grill Burger";
        break;
        }

    case 6:
        {
        temp=180;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Chicken Burger";
        break;
        }

    case 7:
        {
        temp=270;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Zinger Sandwich";
        break;
        }

    case 8:
        {
        temp=240;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Grill Sandwich";
        break;
        }

    case 9:
        {
        temp=200;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Chicken Sandwich";
        break;
        }

    case 10:
        {
        temp=200;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Roll Paratha";
        break;
        }

    case 11:
        {
        temp=150;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Samosa Chat";
        break;
        }

    case 12:
        {
        temp=80;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Small Fries";
        break;
        }

    case 13:
        {
        temp=150;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Large Fries";
        break;
        }

    case 14:
        {
        temp=2000;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Biryani";
        break;
        }

    case 15:
        {
        temp=180;
        total2=temp*quantity2;
        bill=bill+total2;
        item2="Pulao";
        break;
        }
        }

        }

        else if (option == 'N' || option == 'n')
        {
        cout<<"\nThank you Sir/Mam.\n\n";
        cout<<"\nName\t\t\tQuantity\tTotal\n";
        cout<<item1<<"\t\t"<<quantity1<<"\t\t"<<total1<<endl;

        cout<<"\nTotal Quantity:"<<quantity1;
        cout<<"\nTotal Amount:"<<bill;
        tax=(bill/100)*12;
        cout<<"\nGST:"<<tax;
        cout<<"\nTotal:"<<tax+bill<<endl;

        return 0;
        }

        cout<<"Do you want to buy another item(Y or N):";
        cin>>option;
        if(option == 'Y' || option == 'y')
        {
        cout<<"\nEnter the serial number of item:";
        cin>>item;
        cout<<"Enter the quantity of item:";
        cin>>quantity3;
        switch(item)
        {
    case 1:
        {
        temp=200;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Zinger Shawarma";
        break;
        }

    case 2:
        {
        temp=170;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Grill Shawarma";
        break;
        }

    case 3:
        {
        temp=130;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Chicken Shawarma";
        break;
        }

    case 4:
        {
        temp=250;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Zinger Burger";
        break;
        }

    case 5:
        {
        temp=220;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Grill Burger";
        break;
        }

    case 6:
        {
        temp=180;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Chicken Burger";
        break;
        }

    case 7:
        {
        temp=270;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Zinger Sandwich";
        break;
        }

    case 8:
        {
        temp=240;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Grill Sandwich";
        break;
        }

    case 9:
        {
        temp=200;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Chicken Sandwich";
        break;
        }

    case 10:
        {
        temp=200;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Roll Paratha";
        break;
        }

    case 11:
        {
        temp=150;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Samosa Chat";
        break;
        }

    case 12:
        {
        temp=80;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Small Fries";
        break;
        }

    case 13:
        {
        temp=150;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Large Fries";
        break;
        }

    case 14:
        {
        temp=2000;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Biryani";
        break;
        }

    case 15:
        {
        temp=180;
        total3=temp*quantity3;
        bill=bill+total3;
        item3="Pulao";
        break;
        }
        }

        }

        else if (option == 'N' || option == 'n')
        {
        cout<<"\nThank you Sir/Mam.\n\n";
        cout<<"\nName\t\t\tQuantity\tTotal\n";
        cout<<item1<<"\t\t"<<quantity1<<"\t\t"<<total1<<endl;
        cout<<item2<<"\t\t"<<quantity2<<"\t\t"<<total2<<endl;

        cout<<"\nTotal Quantity:"<<quantity1+quantity2;
        cout<<"\nTotal Amount:"<<bill;
        tax=(bill/100)*12;
        cout<<"\nGST:"<<tax;
        cout<<"\nTotal:"<<tax+bill<<endl;

        return 0;
        }

        cout<<"Do you want to buy another item(Y or N):";
        cin>>option;
        if(option == 'Y' || option == 'y')
        {
        cout<<"\nEnter the serial number of item:";
        cin>>item;
        cout<<"Enter the quantity of item:";
        cin>>quantity4;
        switch(item)
        {
    case 1:
        {
        temp=200;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Zinger Shawarma";
        break;
        }

    case 2:
        {
        temp=170;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Grill Shawarma";
        break;
        }

    case 3:
        {
        temp=130;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Chicken Shawarma";
        break;
        }

    case 4:
        {
        temp=250;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Zinger Burger";
        break;
        }

    case 5:
        {
        temp=220;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Grill Burger";
        break;
        }

    case 6:
        {
        temp=180;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Chicken Burger";
        break;
        }

    case 7:
        {
        temp=270;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Zinger Sandwich";
        break;
        }

    case 8:
        {
        temp=240;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Grill Sandwich";
        break;
        }

    case 9:
        {
        temp=200;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Chicken Sandwich";
        break;
        }

    case 10:
        {
        temp=200;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Roll Paratha";
        break;
        }

    case 11:
        {
        temp=150;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Samosa Chat";
        break;
        }

    case 12:
        {
        temp=80;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Small Fries";
        break;
        }

    case 13:
        {
        temp=150;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Large Fries";
        break;
        }

    case 14:
        {
        temp=2000;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Biryani";
        break;
        }

    case 15:
        {
        temp=180;
        total4=temp*quantity4;
        bill=bill+total4;
        item4="Pulao";
        break;
        }
        }

        }

        else if (option == 'N' || option == 'n')
        {
        cout<<"\nThank you Sir/Mam.\n\n";
        cout<<"\nName\t\t\tQuantity\tTotal\n";
        cout<<item1<<"\t\t"<<quantity1<<"\t\t"<<total1<<endl;
        cout<<item2<<"\t\t"<<quantity2<<"\t\t"<<total2<<endl;
        cout<<item3<<"\t\t"<<quantity3<<"\t\t"<<total3<<endl;

        cout<<"\nTotal Quantity:"<<quantity1+quantity2+quantity3;
        cout<<"\nTotal Amount:"<<bill;
        tax=(bill/100)*12;
        cout<<"\nGST:"<<tax;
        cout<<"\nTotal:"<<tax+bill<<endl;

        return 0;

        }

        cout<<"Do you want to buy another item(Y or N):";
        cin>>option;
        if(option == 'Y' || option == 'y')
        {
        cout<<"\nEnter the serial number of item:";
        cin>>item;
        cout<<"Enter the quantity of item:";
        cin>>quantity3;
        switch(item)
        {
    case 1:
        {
        temp=200;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Zinger Shawarma";
        break;
        }

    case 2:
        {
        temp=170;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Grill Shawarma";
        break;
        }

    case 3:
        {
        temp=130;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Chicken Shawarma";
        break;
        }

    case 4:
        {
        temp=250;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Zinger Burger";
        break;
        }

    case 5:
        {
        temp=220;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Grill Burger";
        break;
        }

    case 6:
        {
        temp=180;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Chicken Burger";
        break;
        }

    case 7:
        {
        temp=270;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Zinger Sandwich";
        break;
        }

    case 8:
        {
        temp=240;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Grill Sandwich";
        break;
        }

    case 9:
        {
        temp=200;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Chicken Sandwich";
        break;
        }

    case 10:
        {
        temp=200;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Roll Paratha";
        break;
        }

    case 11:
        {
        temp=150;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Samosa Chat";
        break;
        }

    case 12:
        {
        temp=80;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Small Fries";
        break;
        }

    case 13:
        {
        temp=150;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Large Fries";
        break;
        }

    case 14:
        {
        temp=2000;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Biryani";
        break;
        }

    case 15:
        {
        temp=180;
        total5=temp*quantity5;
        bill=bill+total5;
        item5="Pulao";
        break;
        }
        }

        }


        else if (option == 'N' || option == 'n')
        {
        cout<<"\nThank you Sir/Mam.\n\n";
        cout<<"\nName\t\t\tQuantity\tTotal\n";
        cout<<item1<<"\t\t"<<quantity1<<"\t\t"<<total1<<endl;
        cout<<item2<<"\t\t"<<quantity2<<"\t\t"<<total2<<endl;
        cout<<item3<<"\t\t"<<quantity3<<"\t\t"<<total3<<endl;
        cout<<item4<<"\t\t"<<quantity4<<"\t\t"<<total4<<endl;

        cout<<"\nTotal Quantity:"<<quantity1+quantity2+quantity3+quantity4;
        cout<<"\nTotal Amount:"<<bill;
        tax=(bill/100)*12;
        cout<<"\nGST:"<<tax;
        cout<<"\nTotal:"<<tax+bill<<endl;

        return 0;
        }


        cout<<"Do you want to buy another item(Y or N):";
        cin>>option;
        if(option == 'Y' || option == 'y')
        {
        cout<<"\nEnter the serial number of item:";
        cin>>item;
        cout<<"Enter the quantity of item:";
        cin>>quantity6;
        switch(item)
        {
    case 1:
        {
        temp=200;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Zinger Shawarma";
        break;
        }

    case 2:
        {
        temp=170;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Grill Shawarma";
        break;
        }

    case 3:
        {
        temp=130;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Chicken Shawarma";
        break;
        }

    case 4:
        {
        temp=250;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Zinger Burger";
        break;
        }

    case 5:
        {
        temp=220;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Grill Burger";
        break;
        }

    case 6:
        {
        temp=180;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Chicken Burger";
        break;
        }

    case 7:
        {
        temp=270;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Zinger Sandwich";
        break;
        }

    case 8:
        {
        temp=240;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Grill Sandwich";
        break;
        }

    case 9:
        {
        temp=200;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Chicken Sandwich";
        break;
        }

    case 10:
        {
        temp=200;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Roll Paratha";
        break;
        }

    case 11:
        {
        temp=150;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Samosa Chat";
        break;
        }

    case 12:
        {
        temp=80;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Small Fries";
        break;
        }

    case 13:
        {
        temp=150;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Large Fries";
        break;
        }

    case 14:
        {
        temp=2000;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Biryani";
        break;
        }

    case 15:
        {
        temp=180;
        total6=temp*quantity6;
        bill=bill+total6;
        item6="Pulao";
        break;
        }
        }

        }

        else if (option == 'N' || option == 'n')
        {
        cout<<"\nThank you Sir/Mam.\n\n";
        cout<<"\nName\t\t\tQuantity\tTotal\n";
        cout<<item1<<"\t\t"<<quantity1<<"\t\t"<<total1<<endl;
        cout<<item2<<"\t\t"<<quantity2<<"\t\t"<<total2<<endl;
        cout<<item3<<"\t\t"<<quantity3<<"\t\t"<<total3<<endl;
        cout<<item4<<"\t\t"<<quantity4<<"\t\t"<<total4<<endl;
        cout<<item5<<"\t\t"<<quantity5<<"\t\t"<<total5<<endl;

        cout<<"\nTotal Quantity:"<<quantity1+quantity2+quantity3+quantity4+quantity5;
        cout<<"\nTotal Amount:"<<bill;
        tax=(bill/100)*12;
        cout<<"\nGST:"<<tax;
        cout<<"\nTotal:"<<tax+bill<<endl;
        
        }


        cout<<"\nName\t\t\tQuantity\tTotal\n";
        cout<<item1<<"\t\t"<<quantity1<<"\t\t"<<total1<<endl;
        cout<<item2<<"\t\t"<<quantity2<<"\t\t"<<total2<<endl;
        cout<<item3<<"\t\t"<<quantity3<<"\t\t"<<total3<<endl;
        cout<<item4<<"\t\t"<<quantity4<<"\t\t"<<total4<<endl;
        cout<<item5<<"\t\t"<<quantity5<<"\t\t"<<total5<<endl;
        cout<<item6<<"\t\t"<<quantity6<<"\t\t"<<total6<<endl;

        cout<<"\nTotal Quantity:"<<quantity1+quantity2+quantity3+quantity4+quantity5+quantity6;
        cout<<"\nTotal Amount:"<<bill;
        tax=(bill/100)*12;
        cout<<"\nGST:"<<tax;
        cout<<"\nTotal:"<<tax+bill<<endl;

        return 0;
}
