//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 3 Programing fundamentals
//Dated: 23rd Octuber 2022
//Problem 1

#include <iostream>
using namespace std;
int main()
{
	// All numbers are flagged as false initially
	bool l10 = false, l11 = false, l12 = false, l13 = false, l14 = false, l15 = false, l16 = false, l17 = false, l18 = false, l19 = false;
	
			//lnm where n is the layer number and m is the number between 1-9. for example l13 means "layer 1 and number 3". 
			
	bool l21 = false, l22 = false, l23 = false, l24 = false;
	
			//lnm where n is the layer number and m is the number between 1-4. for example l23 means "layer 2 and number 3". 
			
	int l3;		
	
			//l3 is the layer 3 means the last reconverted number (from binary to decimal). 
			
	int input = 0;
	cout << "Enter which layer you want to set as true\n0:\n1:\n2:\n3:\n4:\n5:\n6:\n7:\n8:\n9:\nPress Accordingly!\n";
	while (true)
	{
		cin >> input;
		if (input >= 0 && input <= 9)
		{
			break;
		}
		cout << "Error: Invalid Input! Please enter 1-9\n";
	}

	//This If is for Layer 1
	if (input == 0) 
	{
		l10 = true;
	}
	else if (input == 1)
	{
		l11 = true;
	}
	else if (input == 2)
	{
		l12 = true;
	}
	else if (input == 3)
	{
		l13 = true;
	}
	else if (input == 4)
	{
		l14 = true;
	}
	else if (input == 5)
	{
		l15 = true;
	}
	else if (input == 6)
	{
		l16 = true;
	}
	else if (input == 7)
	{
		l17 = true;
	}
	else if (input == 8)
	{
		l18 = true;
	}
	else
	{
		l19 = true;
	}

	//This if is for layer 2
	if (l10 == true) {} 						//Binary of 0 =0000
	else if (l11 == true)						//Binary of 1 =0001
	{
		l24 = true;
	}
	else if (l12 == true)						//Binary of 2 =0010
	{
		l23 = true;
	}
	else if (l13 == true)						//Binary of 3 =0011
	{
		l23 = true;
		l24 = true;
	}
	else if (l14 == true)						//Binary of 4 =0100
	{
		l22 = true;
	}
	else if (l15 == true)						//Binary of 5 =0101
	{
		l22 = true;
		l24 = true;
	}
	else if (l16 == true)						//Binary of 6 =0110
	{
		l22 = true;
		l23 = true;
	}
	else if (l17 == true)						//Binary of 7 =0111
	{
		l22 = true;
		l23 = true;
		l24 = true;
	}
	else if (l18 == true)						//Binary of 8 =1000
	{
		l21 = true;
	}
	else
	{
		l21 = true;						//Binary of 9 =1001
		l24 = true;
	}

	cout << "\nThe Binary Equivalent is: " << l21 << l22 << l23 << l24 << endl;	//for second layer 

	switch(l21)
	{
		case true:
			switch (l22)
			{
				case true:
					switch (l23)
					{
						case true:
							switch (l24)
							{
								case true:
									l3 = 15;	//1111 is binary of 15
									break;
								case false:
									l3 = 14;	//1110 is binary of 14
									break;
							}
							break;
						case false:
							switch (l24)
							{
								case true:
									l3 = 13;	//1101 is binary of 13
									break;
								case false:
									l3 = 12;	//1100 is binary of 12
									break;
							}
							break;
					}
					break;
				case false:
					switch (l23)
					{
						case true:
							switch (l24)
							{
								case true:
									l3 = 11;	//1011 is the binary of 11
									break;
								case false:
									l3 = 10;	//1010 is the binary of 10
									break;
							}
							break;
						case false:
							switch (l24)
							{
								case true:
									l3 = 9;		//1001 is the binary of 9
									break;
								case false:
									l3 = 8;		//1000 is the binary of 8
									break;
							}
							break;
					}
					break;
			}
			break;
		case false:
			switch(l22)
			{
				case true:
					switch (l23)
					{
						case true:
							switch (l24)
							{
								case true:
									l3 = 7;		//0111 is the binary of 7
									break;
								case false:
									l3 = 6;		//0110 is the binary of 6
									break;
							}
							break;
						case false:
							switch (l24)
							{
								case true:
									l3 = 5;		//0101 is the binary of 5
									break;
								case false:
									l3 = 4;		//0100 is the binary of 4
									break;
							}
							break;
					}
					break;
				case false:
					switch (l23)
					{
					case true:
						switch (l24)
						{
							case true:
								l3 = 3;			//0011 is the binary of 3
								break;
							case false:
								l3 = 2;			//0010 is the binary of 2
								break;
						}
						break;
					case false:
						switch (l24)
						{
							case true:
								l3 = 1;			//0001 is the binary of 1
								break;
							case false:
								l3 = 0;			//0000 is the binary of 0
								break;
						}
						break;
					}
					break;
			}
			break;
	}

	cout << "\nFinal Layer Value: " << l3 << endl;					//final reconverted answer 

	return 0;
}
