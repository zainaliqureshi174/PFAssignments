//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 3 Programing fundamentals
//Dated: 23rd Octuber 2022
//Problem 4

#include <iostream>
using namespace std;
int main()
{
    int num, x, y, z =0,w =0;         //num = Decimal number 
    string Hnum = "";   //Hnum = Hexadecimal number 
    char hex[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	cout << " Input a decimal number to convert in Hexadecimal and Octal: \n";
	cin>> num;
	

	while (num>=16) {
	
		y=num%16;
		num=num/16;
		
		if (num<16) {
		cout << num;
		}
		
//		else if (num>=16) {
//			z=num%16;
//			num=num/16;
//			if (num<16) {
//			cout << num;
//			}
//			else if (num>=16) {
//			w=num%16;
//			num=num/16;
//			cout<<num<<w;
		if (num <16) {
			break;
		}

	cout<<y;
	}
	return 0; 
	
}














