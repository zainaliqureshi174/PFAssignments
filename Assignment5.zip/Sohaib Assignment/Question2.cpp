// This is a generic code for the problem 2 in this assignment 
#include <iostream>
using namespace std;

int main()
{
	int str = 0;
	float abs = 0;
	int pres = 0;
	cout << "Enter the total strength of students.\n";
	cin >> str;
	cout << "Enter the percentage of absent students (without % sign).\n";
	cin >> abs;
	abs /= 100;
	pres = str * abs;
	pres = str - pres;

	cout << "Total Present students are: " << pres << endl;
	return 0;
}