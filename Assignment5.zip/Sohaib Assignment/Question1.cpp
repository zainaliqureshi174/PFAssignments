/*Question 1

code:


*/
#include <iostream>
using namespace std;

int main()
{
	int med = 0;
	int sum = 0;
	cout << "\tWelcome to Sohaib medical store\n\n";
	cout << "You can only buy 5 medicines at a time.\n";
	cout << "Enter the number of medicines you want to buy: ";
	cin >> med;

	int p1 = 0, p2 = 0, p3 = 0, p4 = 0, p5 = 0;
	if (med > 0 && med <= 5)
	{
		if (med >= 1)
		{
			do
			{
				cout << "Enter Price of the Medicine 1: ";
				cin >> p1;
				sum += p1;
			} while (p1 < 0);
			if (med >= 2)
			{
				do
				{
					cout << "Enter Price of the Medicine 2: ";
					cin >> p2;
					sum += p2;
				} while (p2 < 0);
				if (med >= 3)
				{
					do
					{
						cout << "Enter Price of the Medicine 3: ";
						cin >> p3;
						sum += p3;
					} while (p3 < 0);
					if (med >= 4)
					{
						do
						{
							cout << "Enter Price of the Medicine 4: ";
							cin >> p4;
							sum += p4;
						} while (p4 < 0);
						if (med == 5)
						{
							do
							{
								cout << "Enter Price of the Medicine 5: ";
								cin >> p5;
								sum += p5;
							} while (p5 < 0);
						}
					}
				}
			}
		}
	}

	else
	{
		cout << "Please enter a valid number.\n";
	}

	cout << "\t\t ____________________ \n";
	cout << "\t\t|                    |\n";
	cout << "\t\t|Sohaib Medical Store|\n";
	cout << "\t\t|-----01/05/2023-----|\n";
	cout << "\t\t|--RecieptID:123456--|\n";
	cout << "\t\t|____________________|\n";
	
	if (med >= 1)
	{
		cout << "\tMedicine 1 ---------------- " << p1 << endl;
		if (med >= 2)
		{
			cout << "\tMedicine 2 ---------------- " << p2 << endl;
			if (med >= 3)
			{
				cout << "\tMedicine 3 ---------------- " << p3 << endl;
				if (med >= 4)
				{
					cout << "\tMedicine 4 ---------------- " << p4 << endl;
					if (med >= 5)
					{
						cout << "\tMedicine 5 ---------------- " << p5 << endl;
					}
				}
			}
		}
	}
	
	cout << "\tTotal bill ---------------- " << sum << endl;

	float disc = 0;
	if (sum >= 1000 && sum < 5000)
	{
		cout << "\tDiscount = ---------------- 1%\n";
		disc = sum * .01;
		disc = sum - disc;
		cout << "\tBill due = ---------------- " << disc << endl;
	}
	else if (sum >= 5000 && sum < 10000)
	{
		cout << "\tDiscount = ---------------- 2%\n";
		disc = sum * .02;
		disc = sum - disc;
		cout << "\tBill due = ---------------- " << disc << endl;
	}
	else if (sum >= 10000 && sum < 15000)
	{
		cout << "\tDiscount = ---------------- 3%\n";
		disc = sum * .03;
		disc = sum - disc;
		cout << "\tBill due = ---------------- " << disc << endl;
	}
	else if (sum >= 15000 && sum < 20000)
	{
		cout << "\tDiscount = ---------------- 4%\n";
		disc = sum * .04;
		disc = sum - disc;
		cout << "\tBill due = ---------------- " << disc << endl;
	}
	else if (sum >= 20000)
	{
		cout << "\tDiscount = ---------------- 5%\n";
		disc = sum * .05;
		disc = sum - disc;
		cout << "\tBill due = ---------------- " << disc << endl;
	}
	return 0;
}