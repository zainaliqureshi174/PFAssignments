/*Question 3

Code: 
*/
#include <iostream>
using namespace std;

int main()
{
	int bp = 0;
	cout << "Enter the Systolic Blood Pressure: ";
	cin >> bp;

	if (bp > 0 && bp < 120)
	{
		cout << "\tSystolic Blood Pressure \t Category\n";
		cout << "\tUnder 120 \t\t\t Normal\n";
	}
	else if (bp >= 120 && bp < 140)
	{
		cout << "\tSystolic Blood Pressure \t Category\n";
		cout << "\t120 - 139 \t\t\t Pre-hypertension\n";
	}
	else if (bp >= 140)
	{
		cout << "\tSystolic Blood Pressure \t Category\n";
		cout << "\t140 and Above \t\t\t Hypertension\n";
	}

	else
	{
		cout << "Enter a valid number!!!\n";
	}

	return 0;
}