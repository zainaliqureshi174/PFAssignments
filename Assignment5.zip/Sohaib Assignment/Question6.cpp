/*Question 6

Code:
*/
#include <iostream>
using namespace std;

int main()
{
	char veh = 'a';
	int days;

	cout << "Motorcycle: M\nCar: C\nBus: B\n";
	cout << "Enter the Type of Vehicle: ";
	cin >> veh;

	if (veh == 'M' || veh == 'm' || veh == 'B' || veh == 'b' || veh == 'C' || veh == 'c')
	{
		cout << "Enter days for parking: ";
		cin >> days;

		if (veh == 'M' || veh == 'm')
		{
			cout << "Your bill for " << days << " Parking is " << days * 10 << endl;
		}
		else if (veh == 'C' || veh == 'c')
		{
			cout << "Your bill for " << days << " Parking is " << days * 20 << endl;
		}
		else if (veh == 'B' || veh == 'b')
		{
			cout << "Your bill for " << days << " Parking is " << days * 30 << endl;
		}
	}
	else 
	{
		cout << "Enter a valid character!!!\n";
	}
	return 0;
}