/*Question 9

Code:

*/
#include <iostream>
using namespace std;

int main()
{
	int num1;
	int num2;

	cout << "Enter 2 numbers, 1st number must be less than second one.\n";

	cout << "Enter 1st number: ";
	cin >> num1;
	cout << "Enter 2nd number: ";
	cin >> num2;

	if (num1 > num2)
	{
		cout << "First number is greater then second number!!!\n";
		for (;num1 > num2;)
		{
			cout << "Enter 1st number: ";
			cin >> num1;
			cout << "Enter 2nd number: ";
			cin >> num2;
		}
	}

	cout << "Odd numbers between your added numbers are: ";

	for (int i = num1; i <= num2; i++)
	{
		if (i % 2 == 1)
			cout << i << " ";
	}
	cout << endl;

	cout << "Even numbers between your added numbers are : ";

	for (int i = num1; i <= num2; i++)
	{
		if (i % 2 == 0)
			cout << i << " ";
	}
	cout << endl;

	cout << "Squares of numbers between 1 to 10.\n";

	for (int i = 1; i <= 10; i++)
	{
		cout << i << " x " << i << " = " << i * i << endl;
	}
	cout << endl;

	cout << "Squares of Odd numbers between your added numbers are: \n";

	for (int i = num1; i <= num2; i++)
	{
		if (i % 2 == 1)
			cout << i << " x " << i << " = " << i * i << endl;
	}
	cout << endl;
	return 0;
}