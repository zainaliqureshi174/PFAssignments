/*question 10
code:
*/
#include <iostream>
using namespace std;

int main()
{

	string choice = "0";
	cout << "Enter the serial number, Which program you want to execute.\n";
	cout << "Enter Q to quiet.\n";

	while (choice != "Q" || choice != "q")
	{
		cout << "Enter choice: ";
		cin >> choice;

		if (choice == "1")
		{
			int med = 0;
			int sum = 0;
			cout << "\tWelcome to Sohaib medical store\n\n";
			cout << "You can only buy 5 medicines at a time.\n";
			cout << "Enter the number of medicines you want to buy: ";
			cin >> med;

			int p1 = 0, p2 = 0, p3 = 0, p4 = 0, p5 = 0;
			if (med > 0 && med <= 5)
			{
				if (med >= 1)
				{
					do
					{
						cout << "Enter Price of the Medicine 1: ";
						cin >> p1;
						sum += p1;
					} while (p1 < 0);
					if (med >= 2)
					{
						do
						{
							cout << "Enter Price of the Medicine 2: ";
							cin >> p2;
							sum += p2;
						} while (p2 < 0);
						if (med >= 3)
						{
							do
							{
								cout << "Enter Price of the Medicine 3: ";
								cin >> p3;
								sum += p3;
							} while (p3 < 0);
							if (med >= 4)
							{
								do
								{
									cout << "Enter Price of the Medicine 4: ";
									cin >> p4;
									sum += p4;
								} while (p4 < 0);
								if (med == 5)
								{
									do
									{
										cout << "Enter Price of the Medicine 5: ";
										cin >> p5;
										sum += p5;
									} while (p5 < 0);
								}
							}
						}
					}
				}
			}

			else
			{
				cout << "Please enter a valid number.\n";
			}

			cout << "\t\t ____________________ \n";
			cout << "\t\t|                    |\n";
			cout << "\t\t|Sohaib Medical Store|\n";
			cout << "\t\t|-----01/05/2023-----|\n";
			cout << "\t\t|--RecieptID:123456--|\n";
			cout << "\t\t|____________________|\n";

			if (med >= 1)
			{
				cout << "\tMedicine 1 ---------------- " << p1 << endl;
				if (med >= 2)
				{
					cout << "\tMedicine 2 ---------------- " << p2 << endl;
					if (med >= 3)
					{
						cout << "\tMedicine 3 ---------------- " << p3 << endl;
						if (med >= 4)
						{
							cout << "\tMedicine 4 ---------------- " << p4 << endl;
							if (med >= 5)
							{
								cout << "\tMedicine 5 ---------------- " << p5 << endl;
							}
						}
					}
				}
			}

			cout << "\tTotal bill ---------------- " << sum << endl;

			int disc = 0;
			if (sum >= 1000 && sum < 5000)
			{
				cout << "\tDiscount = ---------------- 1%\n";
				disc = sum * .01;
				disc = sum - disc;
				cout << "\tBill due = ---------------- " << disc << endl;
			}
			if (sum >= 5000 && sum < 10000)
			{
				cout << "\tDiscount = ---------------- 2%\n";
				disc = sum * .02;
				disc = sum - disc;
				cout << "\tBill due = ---------------- " << disc << endl;
			}
			if (sum >= 10000 && sum < 15000)
			{
				cout << "\tDiscount = ---------------- 3%\n";
				disc = sum * .03;
				disc = sum - disc;
				cout << "\tBill due = ---------------- " << disc << endl;
			}
			if (sum >= 15000 && sum < 20000)
			{
				cout << "\tDiscount = ---------------- 4%\n";
				disc = sum * .04;
				disc = sum - disc;
				cout << "\tBill due = ---------------- " << disc << endl;
			}
			if (sum >= 20000)
			{
				cout << "\tDiscount = ---------------- 5%\n";
				disc = sum * .05;
				disc = sum - disc;
				cout << "\tBill due = ---------------- " << disc << endl;
			}


		}
		else if (choice == "2")
		{
			// This is a generic code for the problem 2 in this assignment 

			int str = 0;
			float abs = 0;
			int pres = 0;
			cout << "Enter the total strength of students.\n";
			cin >> str;
			cout << "Enter the percentage of absent students (without % sign).\n";
			cin >> abs;
			abs /= 100;
			pres = str * abs;
			pres = str - pres;

			cout << "Total Present students are: " << pres << endl;

		}
		else if (choice == "3")
		{

			int bp = 0;
			cout << "Enter the Systolic Blood Pressure: ";
			cin >> bp;

			if (bp > 0 && bp < 120)
			{
				cout << "\tSystolic Blood Pressure \t Category\n";
				cout << "\tUnder 120 \t\t\t Normal\n";
			}
			else if (bp >= 120 && bp < 140)
			{
				cout << "\tSystolic Blood Pressure \t Category\n";
				cout << "\t120 - 139 \t\t\t Pre-hypertension\n";
			}
			else if (bp >= 140)
			{
				cout << "\tSystolic Blood Pressure \t Category\n";
				cout << "\t140 and Above \t\t\t Hypertension\n";
			}

			else
			{
				cout << "Enter a valid number!!!\n";
			}

		}
		else if (choice == "4")
		{

			int num = 0;
			cout << "Enter the number in range of 1 - 20 to check its divisors.\n";
			cin >> num;

			if (num >= 1 && num <= 20)
			{
				cout << "Positive divisors of " << num << " are: ";
				int div = 0;
				int count = 0;
				for (int i = 1; i <= num; i++)
				{
					div = num / i;
					if (num % i == 0)
					{
						cout << " " << div;
						count++;
					}
				}
				cout << "\nTotal Divisors: " << count << endl;
			}
			else
			{
				cout << "Number must be in range of 1 to 20!!!\n";
			}

		}
		else if (choice == "5")
		{

			int num = 0;

			cout << "Enter a number between 1 to 12: ";
			cin >> num;

			if (num >= 1 && num <= 12)
			{

				switch (num)
				{
				case 1:
					cout << "It's January.\n";
					break;
				case 2:
					cout << "It's February.\n";
					break;
				case 3:
					cout << "It's March.\n";
					break;
				case 4:
					cout << "It's April.\n";
					break;
				case 5:
					cout << "It's May.\n";
					break;
				case 6:
					cout << "It's June.\n";
					break;
				case 7:
					cout << "It's July.\n";
					break;
				case 8:
					cout << "It's August.\n";
					break;
				case 9:
					cout << "It's September.\n";
					break;
				case 10:
					cout << "It's Octuber.\n";
					break;
				case 11:
					cout << "It's November.\n";
					break;
				case 12:
					cout << "It's December.\n";
					break;
				}
			}

			else {
				cout << "Enter in range of 1 to 12!!!.\n";
			}


		}
		else if (choice == "6")
		{

			char veh = 'a';
			int days;
			cout << "Enter the Type of Vehicle: ";
			cin >> veh;

			if (veh == 'M' || veh == 'm' || veh == 'B' || veh == 'b' || veh == 'C' || veh == 'c')
			{
				cout << "Enter days for parking: ";
				cin >> days;

				if (veh == 'M' || veh == 'm')
				{
					cout << "Your bill for " << days << " Parking is " << days * 10 << endl;
				}
				else if (veh == 'C' || veh == 'c')
				{
					cout << "Your bill for " << days << " Parking is " << days * 20 << endl;
				}
				else if (veh == 'B' || veh == 'b')
				{
					cout << "Your bill for " << days << " Parking is " << days * 30 << endl;
				}
			}
			else
			{
				cout << "Enter a valid character!!!\n";
			}


		}
		else if (choice == "7")
		{

			int min = 10;
			int max = 10;
			int num = 0;

			cout << "Enter numbers and to stop, Press =99.\n";

			while (num != -99)
			{
				cin >> num;
				if (num != -99)
				{
					if (min > num)
					{
						min = num;
					}
					if (max < num)
					{
						max = num;
					}
				}
			}

			cout << "Largest number entered is: " << max << endl;
			cout << "Smallest number entered is: " << min << endl;


		}
		else if (choice == "8")
		{


			int num1;
			int num2;
			cout << "Enter 2 numbers, 1st number must be less than second one.\n";

			cout << "Enter 1st number: ";
			cin >> num1;
			cout << "Enter 2nd number: ";
			cin >> num2;

			if (num1 > num2)
			{
				cout << "First number is greater then second number!!!\n";
				while (num1 > num2)
				{
					cout << "Enter 1st number: ";
					cin >> num1;
					cout << "Enter 2nd number: ";
					cin >> num2;
				}
			}

			cout << "Odd numbers between your added numbers are: ";
			int i = num1;

			while (i <= num2)
			{
				if (i % 2 == 1)
					cout << i << " ";

				i++;
			}
			cout << endl;

			cout << "Even numbers between your added numbers are : ";
			int j = num1;
			while (j <= num2)
			{
				if (j % 2 == 0)
					cout << j << " ";
				j++;
			}
			cout << endl;

			cout << "Squares of numbers between 1 to 10.\n";

			int k = 1;

			while (k <= 10)
			{
				cout << k << " x " << k << " = " << k * k << endl;
				k++;
			}
			cout << endl;

			cout << "Squares of Odd numbers between your added numbers are: \n";

			while (num1 <= num2)
			{
				if (num1 % 2 == 1)
					cout << num1 << " x " << num1 << " = " << num1 * num1 << endl;
				num1++;
			}
			cout << endl;

		}
		else if (choice == "9")
		{

			int num1;
			int num2;

			cout << "Enter 2 numbers, 1st number must be less than second one.\n";

			cout << "Enter 1st number: ";
			cin >> num1;
			cout << "Enter 2nd number: ";
			cin >> num2;

			if (num1 > num2)
			{
				cout << "First number is greater then second number!!!\n";
				for (;num1 > num2;)
				{
					cout << "Enter 1st number: ";
					cin >> num1;
					cout << "Enter 2nd number: ";
					cin >> num2;
				}
			}

			cout << "Odd numbers between your added numbers are: ";

			for (int i = num1; i <= num2; i++)
			{
				if (i % 2 == 1)
					cout << i << " ";
			}
			cout << endl;

			cout << "Even numbers between your added numbers are : ";

			for (int i = num1; i <= num2; i++)
			{
				if (i % 2 == 0)
					cout << i << " ";
			}
			cout << endl;

			cout << "Squares of numbers between 1 to 10.\n";

			for (int i = 1; i <= 10; i++)
			{
				cout << i << " x " << i << " = " << i * i << endl;
			}
			cout << endl;

			cout << "Squares of Odd numbers between your added numbers are: \n";

			for (int i = num1; i <= num2; i++)
			{
				if (i % 2 == 1)
					cout << i << " x " << i << " = " << i * i << endl;
			}
			cout << endl;

		}
		else if (choice == "Q" || choice == "q")
		{
			break;
		}
		else
		{
			cout << "Enter between 1 - 9\n";
		}


		
	}

}
