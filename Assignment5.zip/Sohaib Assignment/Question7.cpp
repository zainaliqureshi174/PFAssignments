/*Question 7

Code:

*/

#include <iostream>
using namespace std;

int main()
{

	int min = 10;
	int max = 10;
	int num = 0;

	cout << "Enter numbers and to stop, Press =99.\n";

	while (num != -99)
	{
		cin >> num;
		if (num != -99)
		{
			if (min > num)
			{
				min = num;
			}
			if (max < num)
			{
				max = num;
			}
		}
	}

	cout << "Largest number entered is: " << max << endl;
	cout << "Smallest number entered is: " << min << endl;

	return 0;
}