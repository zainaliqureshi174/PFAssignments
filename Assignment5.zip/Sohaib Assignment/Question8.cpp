/*Question 8

Code:

*/
#include <iostream>
using namespace std;

int main()
{
	int num1;
	int num2;
	cout << "Enter 2 numbers, 1st number must be less than second one.\n";
	
	cout << "Enter 1st number: ";
	cin >> num1;
	cout << "Enter 2nd number: ";
	cin >> num2;

	if (num1 > num2)
	{
		cout << "First number is greater then second number!!!\n";
		while (num1 > num2)
		{
			cout << "Enter 1st number: ";
			cin >> num1;
			cout << "Enter 2nd number: ";
			cin >> num2;
		}
	}

	cout << "Odd numbers between your added numbers are: ";
	int i = num1;

	while (i <= num2)
	{
		if (i % 2 == 1)
		cout << i << " ";

		i++;
	}
	cout << endl;

	cout << "Even numbers between your added numbers are : ";
	int j = num1;
	while (j <= num2)
	{
		if (j % 2 == 0)
			cout << j << " ";
		j++;
	}
	cout << endl;

	cout << "Squares of numbers between 1 to 10.\n";
	
	int k = 1;

	while(k <= 10)
	{
		cout << k << " x " << k << " = " << k * k << endl;
		k++;
	}
	cout << endl;

	cout << "Squares of Odd numbers between your added numbers are: \n";

	while (num1 <= num2)
	{
		if (num1 % 2 == 1)
		cout << num1 << " x " << num1 << " = " << num1 * num1 << endl;
		num1++;
	}
	cout << endl;
	return 0;
}