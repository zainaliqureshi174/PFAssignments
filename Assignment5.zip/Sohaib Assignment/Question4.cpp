/*Question 4

Code :

*/
#include <iostream>
using namespace std;

int main()
{
	

		int num = 0;
		cout << "Enter the number in range of 1 - 20 to check its divisors.\n";
		cin >> num;

		if (num >= 1 && num <= 20)
		{
			cout << "Positive divisors of " << num << " are: ";
			int div = 0;
			int count = 0;
			for (int i = 1; i <= num; i++)
			{
				div = num / i;
				if (num % i == 0)
				{
					cout << " " << div;
					count++;
				}
			}
			cout << "\nTotal Divisors: " << count << endl;
		}
		else
		{
			cout << "Number must be in range of 1 to 20!!!\n";
		}

		return 0;
}