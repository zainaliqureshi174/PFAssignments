//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 4 Programing fundamentals
//Dated: 19 November 2022
//Problem 2

#include <iostream>
using namespace std;

void Menue();					//Menu function
void Customermode();				//Customers Function
void Managermode();				//Manager Function

string name[100000];
string  contact;
char choice;
int mode;

//int sr[];
//int qt[];
int prices[20] = {20, 30, 50, 80, 200, 200, 150, 200, 180, 150, 150, 140, 100, 250, 220, 180, 80, 150, 200, 100};	//Array for prices

string item[20] = {"Roti" , "Paratha" , "Tea" , "Coffee" , "Qeema Aalu" , "Nihaari" , "Daal Maash" , "Zinger Burger" , "Zinger Shwarma" , "Zinger Sandwitch" , "Chicken Burger" , "Chicken Shwarma" , "Chicken Sandwitch" , "Grill Burger" , "Grill Shwarma" , "Grill Sandwitch" , "Small Fries" , "Medium Fries" , "Loaded Fries" , "Raaita Salaad"};			//Array for Order items


int main ()					//Main Function
{
	cout << "\n\tSelect between the following options:\n\t1. Customer mode\n\t2. Manager mode\n\n\t";

	cin >> mode;

	if (mode == 1)
	{
		Customermode();			//Customer Function calling
	}
	else if (mode == 2)
	{
		Managermode();			//Manager Function calling
	}
	else 
		cout << "Enter a valid option!!";
		
		
		
	return 0;
}

void Customermode()				//Customer function
{


int i = 0, j = 0;	
	do{
		cout <<"\nEnter your name: ";
		cin >>name[i];						//name
		
		cout <<"Enter your contact number: ";
		cin >>contact;						//contact
		
		
			do {
				cout <<"Dear "<<name[i]<<":\n";
		
				Menue();				//menue function calling
			
				
				cout <<"\n\nSelect your order. Enter a serial number between 1-20 and press 0 to quit orders.\n";
				do {
				
				cout << "\nEnter serial number: ";
//				cin >> sr[j];				//order
//					if (sr_no > 0 && sr_no <= 20)
					{
					cout <<"Enter the quantity: ";
//					cin >> qt[j];		//quantity
					}
					else if (sr_no != 0)
					{
						cout << "Please enter a valid number!!!\n";	
					}
				}
				//while (sr_no != 0);
				j++;	
					
				
				
									//Bill
					cout << "Are you done with this order? If No, Press \"N\", otherwise Press \"Y\" to pass this for next customers.\n";
					cin >> choice;
			}while(choice == 'N' || choice == 'n');
			
	}while (choice == 'Y' || choice == 'y');
	i++;
	
}

void Managermode()
{
	cout << "\n\n\tWelcome to Manager mode\n\n";
	
	cout <<"\tTotal records for the sales is as under:\n\n"; 
	
	cout <<"\tName\tItem\tQuantity\tCost\n";
}

void Menue()						//Menue function
{
	cout <<"\n\t\tWelcome to Zain Restraunt\n";
	cout <<"\t\t-------------------------\n";
	cout <<"\t\t Menue is given as under\n\n";
	cout <<"\tSr.No.\tItem Name\t\tPrice\n";
	cout <<"\t01.\tRoti\t\t\tPKR 20\n";				//01
	cout <<"\t02.\tParatha\t\t\tPKR 30\n";				//02
	cout <<"\t03.\tTea\t\t\tPKR 50\n";				//03
	cout <<"\t04.\tCoffee\t\t\tPKR 80\n";				//04
	cout <<"\t05.\tQeema Aalu\t\tPKR 200\n";			//05
	cout <<"\t06.\tNihaari\t\t\tPKR 200\n";				//06
	cout <<"\t07.\tDaal Maash\t\tPKR 150\n";			//07
	cout <<"\t08.\tZinger Burger\t\tPKR 200\n";			//08
	cout <<"\t09.\tZinger Shwarma\t\tPKR 180\n";			//09
	cout <<"\t10.\tZinger Sandwitch\tPKR 150\n";			//10
	cout <<"\t11.\tChicken Burger\t\tPKR 150\n";			//11
	cout <<"\t12.\tChicken Shwarma\t\tPKR 140\n";			//12
	cout <<"\t13.\tChicken Sandwitch\tPKR 100\n";			//13
	cout <<"\t14.\tGrill Burger\t\tPKR 250\n";			//14
	cout <<"\t15.\tGrill Shwarma\t\tPKR 220\n";			//15
	cout <<"\t16.\tGrill Sandwitch\t\tPkR 180\n";			//16
	cout <<"\t17.\tSmall Fries\t\tPKR 80\n";			//17
	cout <<"\t18.\tMedium Fries\t\tPKR 150\n";			//18
	cout <<"\t19.\tLoaded Fries\t\tPKR 200\n";			//19
	cout <<"\t20.\tRaaita Salaad\t\tPKR 100\n";			//20
	
}
