//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 4 Programing fundamentals
//Dated: 19 November 2022
//Problem 7 (Bonus task)


//This program prints the arrow of the highest row entered by user
#include <iostream>
using namespace std;

int main()
{
	int n;
	
	cout << "\tEnter the size of the Arrow below\n\nInput : n = \n";
	cin >> n;
	
	for (int i = 0; i < n; i++)		//Loop for upper part
	{
		int s = i;
		for (int j = 0; j < s; j++)
		{
			cout << " ";
		}
		for (int k = -1; k < i; k++)
		{
			cout << "*";
		}
		cout << endl ;
	}	
	for (int i = n - 1; i > 0; i--)		//Loop for lower part
	{
		int s = i-1;
		for (int j = s; j > 0; j--)
		{
			cout << " ";
		}
		for (int k = i; k > 0; k--)
		{
			cout << "*";
		}
		cout << endl ;
	}
	
	return 0;
}
