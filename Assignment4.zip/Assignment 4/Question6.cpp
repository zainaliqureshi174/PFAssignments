//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 4 Programing fundamentals
//Dated: 19 November 2022
//Problem 6

#include <iostream>
using namespace std;

void Arr_merge(int Arr1[], int size1, int Arr2[]);

int main ()
{
int size1, size2, size3;
	cout << "Enter the size of both Arrays: ";
	cin >> size1;
	
	int Arr1[size1];
	
	cout << "Enter the integers in Array 1: \n";
	for (int i = 0; i < size1; i++)
	{
		cin >> Arr1[i];
	}
	
	cout << endl;
	
	
	int Arr2[size1];
	
	cout << "Enter the integers in Array 2: \n";
	for (int i = 0; i < size1; i++)
	{
		cin >> Arr2[i];
	}
	
	
	cout << endl;
	
	Arr_merge(Arr1, size1, Arr2);
	
    return 0;
}

void Arr_merge(int Arr1[], int size1, int Arr2[])
{

	cout <<"\nYour Array 1 is: ";
	for (int i = 0; i < size1; i++)
	{
		cout << Arr1[i] << " ";
	}	
	
	cout << endl;
		
	cout <<"Your Array 2 is: ";
	for (int i = 0; i < size1; i++)
	{
		cout << Arr2[i] << " ";
	}
	
	cout << endl;
	
	int size2 = 2*size1;
	int Arr3[size2];
	
	for (int i = 0; i < size1; i++)
	{
			Arr3[i*2]=Arr1[i];
		 
			Arr3[(i*2)+1]=Arr2[i];
	}
	
	cout <<"\nYour alternatively merged Array 3 is: ";
	for (int i = 0; i < size2; i++)
	{
		cout << Arr3[i] << " ";
	}
	
	cout << endl;
	
	for (int i = 0; i < size2; i++)
	{
		for (int j = i+1; j < size2; j++)
		{
			if (Arr3[i] > Arr3[j])
			{
				int temp;
				temp = Arr3[i];
				Arr3[i]=Arr3[j];
				Arr3[j]=temp;
			}
		}
	}
	
	cout<<"Sorted Third Array is: ";
	for (int i = 0; i < size2; i++)
	{
		cout <<Arr3[i] << " ";
	}
	
	cout << "\n\n";
	for (int i = 0; i < size2; i++)
	{
		for (int j = 0; j < size1; j++)
		{ 
			if (Arr3[i] == Arr1[j])
			{
				cout << Arr3[i] << " is from Array 1\n";
			}
			else if (Arr3[i] == Arr2[j])
			{
				cout << Arr3[i] << " is from Array 2\n";
			}
		}
	}
}

