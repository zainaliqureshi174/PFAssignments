//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 4 Programing fundamentals
//Dated: 19 November 2022
//Problem 5

#include<iostream>
using namespace std;

int main()
{
	int Arr1[]{};
	int Arr2[]{};
	int Arr3[]{};
	int size1 = 0, size2 = 0, size3 = 0;

	cout << "Enter the elements in Array 1\n";
	
	while (Arr1[] == 'Q' || Arr1[] == 'q')
	{
		cin >> Arr1[];
	}
	
	cout << "Enter the elements in Array 2\n";
	while (Arr1[] == 'Q' || Arr1[] == 'q')
	{
		cin >> Arr2[];
	}
	
	return 0;
}
