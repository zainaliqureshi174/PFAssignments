//Muhammad Zain Ali 
//22i-0562
//AI-D 
//Assignment 4 Programing fundamentals
//Dated: 19 November 2022
//Problem 1

#include <iostream>
using namespace std;


int size4;

void Arr_merge(int Arr1[], int size1, int Arr2[], int size2, int Arr3[], int size3);

int main ()
{

int size1 = 0, size2 = 0, size3 = 0, size4 = 0;
	
	cout <<"\tEnter 3 Arrays to merge them descendingly in another Array.\n\n";
	cout <<"Enter the size of Array 1: ";
	cin >> size1;
	cout <<"Enter the integers in Array 1.\n";
	
	int Arr1[size1];
	
	for (int i=0; i < size1; i++)
	{
		cin >> Arr1[i];
	}
	
	cout <<"\nIntegers of Array 1 are: \n";
	
	for (int j=0; j < size1; j++)
	{
		cout << Arr1[j]<<endl;
	}
	
	
	for (int i = 0; i < size1; i++)
	{
		for (int j = i + 1; j < size1; j++)
		{
			if (Arr1[i] < Arr1[j])
			{
			int temp;
				temp = Arr1[i];
				Arr1[i] = Arr1[j];
				Arr1[j] = temp;
			}
		}
	}
		
	cout <<"\nEnter the size of Array 2: ";
	cin >> size2;
	cout <<"Enter the integers in Array 2.\n";
	
	int Arr2[size2];
	
	for (int i=0; i < size2; i++)
	{
		cin >> Arr2[i];
	}
	
	cout <<"\nIntegers of Array 2 are: \n";
	
	for (int j=0; j < size2; j++)
	{
		cout << Arr2[j]<<endl;
	}
	
	
	for (int i = 0; i < size2; i++)
	{
		for (int j = i + 1; j < size2; j++)
		{
			if (Arr2[i] < Arr2[j])
			{
			int temp;
				temp = Arr2[i];
				Arr2[i] = Arr2[j];
				Arr2[j] = temp;
			}
		}
	}
	
	cout <<"\nEnter the size of Array 3: ";
	cin >> size3;
	cout <<"Enter the integers in Array 3.\n";
	
	int Arr3[size3];
	
	for (int i=0; i < size3; i++)
	{
		cin >> Arr3[i];
	}
	
	cout <<"\nIntegers of Array 3 are: \n";
	
	for (int j=0; j < size3; j++)
	{
		cout << Arr3[j]<<endl;
	}
	
	
	for (int i = 0; i < size3; i++)
	{
		for (int j = i + 1; j < size3; j++)
		{
			if (Arr3[i] < Arr3[j])
			{
			int temp;
				temp = Arr3[i];
				Arr3[i] = Arr3[j];
				Arr3[j] = temp;
			}
		}
	}
	
	cout << endl;
	
	Arr_merge(Arr1, size1, Arr2, size2, Arr3, size3);
	
	
	
	
	return 0;
}

void Arr_merge(int Arr1[], int size1, int Arr2[], int size2, int Arr3[], int size3)
{

	size4 = size1 + size2 + size3;

int Arr4[size4];	

	for (int i = 0; i < size1; i++)
	{
		Arr4[i] = Arr1[i];
	}
	
	for (int i = 0; i < size2; i++)
	{
		Arr4[size1 + i] = Arr2[i];
	}
	
	for (int i = 0; i < size3; i++)
	{
		Arr4[size1 + size2 + i] = Arr3[i];
	}
	
	
	for (int i = 0; i < size4; i++)
	{
		for (int j = i + 1; j < size4; j++)
		{
			if (Arr4[i] < Arr4[j])
			{
			int temp;
				temp = Arr4[i];
				Arr4[i] = Arr4[j];
				Arr4[j] = temp;
			}
		}
	}
	
	cout << "\nYour sorted Array in descending order is as under: \n";
	
	for (int j = 0; j < size4; j++)
	{
		cout << Arr4[j]<<" ";
	}
	cout << endl;
	
}
